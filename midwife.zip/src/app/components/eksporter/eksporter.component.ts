import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eksporter',
  templateUrl: './eksporter.component.html',
  styleUrls: ['./eksporter.component.css']
})
export class EksporterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
